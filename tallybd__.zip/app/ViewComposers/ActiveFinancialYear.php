<?php

namespace App\ViewComposers;

use App\Companydetail;
use Illuminate\Contracts\View\View;

class ActiveFinancialYear
{

//   public function compose(View $view) {

//     $view->with('settingDate', Companydetail::with('financial_year')->first()->financial_year);
//   }

}
