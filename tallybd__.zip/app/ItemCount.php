<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemCount extends Model
{
    protected $guarded=['id'];
}
