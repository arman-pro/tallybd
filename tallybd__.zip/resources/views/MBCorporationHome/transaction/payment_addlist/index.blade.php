@extends('MBCorporationHome.apps_layout.layout')
@section('title', 'Payment List')
@section('admin_content')

<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card">
                <div class="card-header bg-success">
                    <h4 class="card-title">All List Of Payment</h4>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <a href="{{route('payment_addlist_form')}}" class="btn btn-success">Add New</a>
                    </div>
                    <table class="table table-bordered" id="payment_addlist">
                        <caption>All List Of Payment</caption>
                        <thead class="bg-light text-dark">
                            <tr>
                                <th>SL</th>
                                <th>Date</th>
                                <th>Vch. No</th>
                                <th>Payment Mode</th>
                                <th>Account Ledger</th>
                                <th>Amount</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal" tabindex="-1" id="message_modal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Message</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="message_body">
          
        </div>
        
      </div>
    </div>
  </div>

@endsection
@push('js')
<script>
    $(document).ready(function(){
        $('#payment_addlist').DataTable({
            processing: true,
            serverSide: true,
            columnDefs: [
                { orderable: false, targets: -1 },
                { orderable: false, targets: -3 },
                { orderable: false, targets: -4 },
            ],
            ajax: "{{route('payment_addlist')}}",
            columns: [
                { data: 'id' },
                { data: 'date' },
                { data: 'vo_no' },
                { data: 'payment_mode.account_name', name: 'paymentMode.account_name' },
                { data: 'account_mode.account_name', name: 'accountMode.account_name' },
                { data: 'amount' },
                { data: 'description' },
                { data: 'action' },
            ],
        });

        $(document).on("click", ".view_message", function(){
            let message = $(this).data('message');
            $('#message_modal').modal('show');
            $('#message_body').text(message);
        });

        $(document).on('click', "a.delete_btn", function(){
            var here = $(this);
            var url = "{{url('/delete_payment_addlist')}}"+ '/' +$(this).data('id');

            $.confirm({
                icon: 'fa fa-spinner fa-spin',
                title: 'Delete this?',
                theme: 'material',
                type: 'orange',
                closeIcon: true,
                animation: 'scale',
                content: 'This dialog will automatically trigger \'cancel\' in 6 seconds if you don\'t respond.',
                autoClose: 'cancelAction|8000',
                buttons: {
                    deleteUser: {
                        text: 'delete data',
                        action: function () {
                            $.get(url, function(data){
                                if(data.status == true){
                                    here.closest('tr').remove();
                                }
                                $.alert(data.mes);

                            });
                        }
                    },
                    cancelAction: function () {
                        $.alert('This action is canceled.');
                    }
                }
            });
        });
    });
    
</script>
@endpush

